   var form = document.getElementById('formularioCliente');
    var cerveja = document.getElementById('cerveja');
    var refrigerante = document.getElementById('refrigerante');
    var agua = document.getElementById('agua');
    var sanduiche = document.getElementById('sanduiche');
    var mesa = document.getElementById('mesa');
    var i;

    form.addEventListener("submit", function(e) {
        
        e.preventDefault();
        
        var pedido=[i];
        
        for (var i = 0; i <= 5; i++) {

        if (cerveja.checked) pedido[i] += 'Cerveja ';
        if (refrigerante.checked) pedido[i] += 'Refrigerante ';
        if (agua.checked) pedido[i] += 'Água ';
        if (sanduiche.checked) pedido[i] += 'Sanduíche ';

        var mesaSelecionada = mesa.value;
        
        alert('Pedido ' + i + ': ' + pedido[i] + '\nMesa: ' + mesaSelecionada);
    }
    });